from flask import Flask, render_template, request, redirect,url_for 
import sqlite3

app = Flask(__name__)

# Create the database connection
conn = sqlite3.connect('cart.db' ,check_same_thread=False)
c = conn.cursor()

# Create the cart table if it doesn't exist
c.execute('''CREATE TABLE IF NOT EXISTS cart(name TEXT, price INTEGER, count INTEGER)''')

conn.commit()

# Menu page
@app.route('/')
def main():
    return render_template('main.html')

# Add to cart route
@app.route('/add-to-cart', methods=['POST'])
def add_to_cart():
    name = request.form['name']
    price = int(request.form['price'])

    # Check if the item is already in the cart
    c.execute("SELECT * FROM cart WHERE name=?", (name,))
    row = c.fetchone()
    if row is not None:
        count = row[2] + 1
        c.execute("UPDATE cart SET count=? WHERE name=?", (count, name))
    else:
        c.execute("INSERT INTO cart VALUES (?, ?, 1)", (name, price))

    conn.commit()

    return redirect('/cart')

# Cart page
@app.route('/cart',methods=['GET','POST'])
def cart():
    if request.method == 'POST':
        db = sqlite3.connect('cart.db')
        c = db.cursor()
        c.execute("DELETE FROM cart")
        db.commit()
        return redirect('/cart')
    
    db = sqlite3.connect('cart.db')
    c = db.cursor()
    c.execute("SELECT * FROM cart")
    cart =[{'name':row[0],'price':row[1],'count':row[2]}for row in c.fetchall()]
    total_price = sum(item['price']*item['count'] for item in cart)
    return render_template('cart.html', cart=cart ,total_price=total_price)
    

if __name__ == '__main__':
    app.run(debug=True)